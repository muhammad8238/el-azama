// Pre-Order Function
function preOrder(productName) {
  alert(`Anda telah memilih untuk melakukan pre-order pada produk: ${productName}. Kami akan menghubungi Anda untuk detail lebih lanjut.`);
}

// Animasi Flicker untuk Teks
document.querySelectorAll(".flicker").forEach(element => {
  element.style.animation = "flicker 1.5s infinite alternate";
});

// Keyframe Animasi Flicker di CSS
